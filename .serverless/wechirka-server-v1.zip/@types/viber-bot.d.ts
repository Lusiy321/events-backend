declare module 'viber-bot';
